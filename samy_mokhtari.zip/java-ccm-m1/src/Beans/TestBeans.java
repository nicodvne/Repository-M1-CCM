/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author Samy
 */
public class TestBeans {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /* Instanciation des classes permettant la creation/gestion de 3 employés */
        GestionEmployees gestionEmployees1 = new GestionEmployees(3);
        GestionEmployees gestionEmployees2 = new GestionEmployees(3);

        /* Instanciation des threads */
        Thread t1 = new Thread(gestionEmployees1,"Thread 1");        
        Thread t2 = new Thread(gestionEmployees2,"Thread 2");

        t1.start();        
        t2.start();
    }
}
