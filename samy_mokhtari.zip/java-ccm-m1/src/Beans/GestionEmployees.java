/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author Samy
 */
public class GestionEmployees implements Runnable {

    private ArrayList<Employee> employees;
    private int nombreEmployee;
    private String[] names;

    

    public void setNombreEmployee(int nombreEmployee) {
        this.nombreEmployee = nombreEmployee;
    }
    public void setNombreEmployee(int nombreEmployee, String[] names) {
        if(nombreEmployee != names.length) throw new IllegalArgumentException("Names number must be same as employees number");
        
        setNombreEmployee(nombreEmployee);
        setNames(names);
    }

    public int getNombreEmployee() {
        return nombreEmployee;
    }
    
    public void setEmployees(ArrayList<Employee> employees) {
        this.employees = employees;
    }
    
    public String[] getNames() {
        return names;
    }

    public void setNames(String[] names) {
        this.names = names;
    }

    public ArrayList<Employee> getEmployees() {
        return employees;
    }

    public GestionEmployees(int nombreEmployee) {
        setNombreEmployee(nombreEmployee); 
        setEmployees(new ArrayList<>());
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        for(Employee e : employees) {
            result.append(e.toString() + "\n");
        }
        return result.toString();
    }
       
    @Override
    public void run() {
        int compteur=0;
        while(compteur < nombreEmployee){
            employees.add(new Employee(new Agenda(new ArrayList<MyTask>(
                    Arrays.asList(
                            new MyTask("task", compteur), 
                            new MyTask("task2", compteur+1)
                    )
            )), "FakeNameEmployee"));
            System.out.println(
                    this.employees+"\ncompteur: "+compteur+" - "+Thread.currentThread().getName()
            );
            compteur++;
            try {
                Thread.sleep(300);
            }
            catch(InterruptedException e)
            {
                System.out.println("Petite erreur : " + e.getMessage());
            }
        }
    }
    
}
