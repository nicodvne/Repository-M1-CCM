/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import java.time.LocalDateTime;

/**
 *
 * @author Samy
 */
public class MyTask {
    private String name;

   
    private int priority;
    private LocalDateTime start;
    private boolean finished;

    public MyTask() {
    }

    public MyTask(String name, int priority) {
        setName(name);
        setPriority(priority);
        setStart(LocalDateTime.now());
        setFinished(false);
    }

    public boolean isFinished() {
        return finished;
    }

    public void setFinished(boolean finished) {
        this.finished = finished;
    }

    public void setStart(LocalDateTime start) {
        this.start = start;
    }

    public int getPriority() {
        return priority;
    }

    public LocalDateTime getStart() {
        return start;
    }

    public void setPriority(int order) {
        this.priority = order;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
    @Override
    public String toString() {
        return "Task : " + getName() + " | Priority : " + getPriority() + " | Date :" + getStart();
    }
}
