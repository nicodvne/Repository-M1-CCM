/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pixel;

/**
 *
 * @author Samy
 */
public class Pixel {

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }
    public final static float ORIGIN = 0; //Constante
    private float x;//Champ
    private float y;//Champ
    public Pixel(float x, float y) { //Constructeur
        this.x = x;
        this.y = y;
    }
    public void reset() { //Méthodes d'instances
        x = ORIGIN;
        y = ORIGIN;
    }
    public void printOnScreen() { //Méthodes d'instances
        System.out.println("("+x+","+y+")");
    }
    public static boolean same(Pixel p1, Pixel p2) { //Méthode de classe
        return (p1.x==p2.x) && (p1.y==p2.y);
    }
    
    public static Pixel calcCenter(Pixel pixels[]) {
        float sumX = ORIGIN;
        float sumY = ORIGIN;
        float avgX = ORIGIN;
        float avgY = ORIGIN;
        for(Pixel p : pixels) {
            sumX += p.x;
            sumY += p.y;
        }
        avgX = sumX / pixels.length;
        avgY = sumY / pixels.length;
       
        return new Pixel(avgX, avgY);
    }
    
    public static void main(String[] args) { //Méthode de classe
        Pixel p0 = new Pixel(0,0); //Variables locales à la méthode main et objets de la classe Pixel
        p0.printOnScreen(); // (1,3)
        Pixel p1 = new Pixel(1,3);
        p1.printOnScreen(); // (1,3)
        System.out.println(same(p0,p1)); // false
        //p1.reset();
        System.out.println(same(p0,p1)); // true
        Pixel p2 = new Pixel(4,3);
        Pixel p3 = new Pixel(3,0);
        
        Pixel.calcCenter(new Pixel[] { p0, p1, p2 , p3 }).printOnScreen();
    }
}
