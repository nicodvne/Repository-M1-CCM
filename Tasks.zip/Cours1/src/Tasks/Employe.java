/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tasks;

/**
 *
 * @author Jeremy KRZ
 */
public class Employe extends Thread{
    
    private final Agenda agenda;
    private boolean isFinish;
    
    public Employe(Agenda agenda){
        this.agenda = agenda;
        isFinish = false;
    }
    @Override
    public void run(){
        while(!isFinish){
            try{
                sleep(5000);
                faireTache();
            }catch(InterruptedException ex){
                System.out.println("Erreur ! ");
            }
        }
    }
    
    private void faireTache(){
        if(!agenda.getRemainingTasks().isEmpty()){
            System.out.println("Tache à effectuer : ");
            agenda.getRemainingTasks().get(0).Affiche_tache();
            agenda.getRemainingTasks().get(0).setEffectuee(true);
            System.out.println("\nTache terminée !\n");
        }else{
            isFinish = true;
        }
        
    }
}
