/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tasks;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Jeremy KRZ
 */
public class Agenda {
    private final ArrayList<Tache> taches;
    
    public Agenda(ArrayList<Tache> taches){
        this.taches = taches;
    }
    
    public void AddTask(Tache tache){
        taches.add(tache);
    }
    
    public void AddTask(ArrayList<Tache> taches){
        taches.forEach(tache -> this.taches.add(tache));
    }
    
    public void AddTask(String libelle, int prio, LocalDateTime date, boolean effectuee){
        Tache tache = new Tache(libelle,prio,date);
        taches.add(tache);
    }
    
    public void getEndedTask(){
        System.out.println("\nTaches effectuees : ");
        for(int i=0; i<taches.size();i++){
            if (taches.get(i).isEffectuee()){
                taches.get(i).Affiche_tache();
            }
        }
    }
    
    /*public java.util.List<Tache> getByDate(Date date){
        return taches.stream().filter(tache->tache.getDate().equals(date)).collect(Collectors.toList());
    }*/
    
    public void getByDate(Date date){
        for(int i=0; i<taches.size();i++){
            if (taches.get(i).getDate().equals(date)){
                taches.get(i).Affiche_tache();
            }
        }
    }
    
    public ArrayList<Tache> getTasks(){
        return taches;
    }
    
    public ArrayList<Tache> getRemainingTasks(){
        ArrayList<Tache> remainingTasks = new ArrayList<>();
        for(int i=0; i<taches.size();i++){
            if (!taches.get(i).isEffectuee()){
                remainingTasks.add(taches.get(i));
            }
        }
        return remainingTasks;
    }
}

