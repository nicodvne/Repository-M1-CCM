/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tasks;

import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 *
 * @author Jeremy KRZ
 */
public class Main {
    public static void main(String[] args) {
        
        Tache tache1 = new Tache("tache1",1,LocalDateTime.now());
        Tache tache2 = new Tache("tache2",2,LocalDateTime.now());
        Tache tache3 = new Tache("tache3",3,LocalDateTime.now());
        
        tache3.Affiche_tache();
        ArrayList<Tache> taches = new ArrayList<>();
        taches.add(tache1);
        taches.add(tache2);
        
        Agenda agenda1 = new Agenda(taches);
        
        Employe employe1 = new Employe(agenda1);
        
        try{
            employe1.start();
            
            employe1.join();
        }catch(InterruptedException ex){
        }
        
        System.out.println("\n------------Terminer--------------------");
    }
}
