/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tasks;

import java.time.LocalDateTime;

/**
 *
 * @author Jeremy KRZ
 */
public class Tache {
    private String libelle;
    private int priorite;
    private LocalDateTime date;
    private boolean effectuee;
    
    public Tache(String lib, int prio, LocalDateTime date){
        this.libelle = lib;
        this.priorite = prio;
        this.date = date;
        this.effectuee = false;
    }
    
    public void Affiche_tache(){
        System.out.println("Libelle : "+this.libelle + "\nPriorité : "+this.priorite
                +"\nDate : " + this.date.toString() + "\nEffectuee : " + String.valueOf(this.effectuee));
    }
    
    public String getLibelle(){
        return this.libelle;
    }
    public boolean isEffectuee(){
        return this.effectuee;
    }
    
    public LocalDateTime getDate(){
        return this.date;
    }
    
    public int getPriorite(){
        return this.priorite;
    }
    
    public void setLibelle(String libelle){
        this.libelle = libelle;
    }
    public void setPriorite(int priorite){
        this.priorite = priorite;
    }
    public void setEffectuee(boolean effectuee){
        this.effectuee = effectuee;
    }
    public void setDate(LocalDateTime date){
        this.date = date;
    }
    
    
}

